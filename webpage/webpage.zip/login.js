window.addEventListener('load', function() {
  // Get the modal element
  const modal = document.getElementById('login-modal');

  // Show the modal
  modal.style.display = 'block';
});